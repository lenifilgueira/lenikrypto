// Place any global data in this file.
// You can import this data from anywhere in your site by using the `import` keyword.

export const SITE_TITLE = 'lenikrypto - Exploring Bitcoing & Crypto';
export const SITE_DESCRIPTION = 'Exploring Bitcoing & Crypto - one block at a time';
